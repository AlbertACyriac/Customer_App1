customer_data = [
    {
        "id": 1,
        "name": "Alice Smith",
        "email": "alice@example.com",
        "phone": "1234567890",
        "address": "123 Apple St",
        "membership": "Gold",
        "join_date": "2022-07-23",
        "balance": 150.75
    },
    {
        "id": 2,
        "name": "Bob Johnson",
        "email": "bob@example.com",
        "phone": "2345678901",
        "address": "456 Orange Ave",
        "membership": "Silver",
        "join_date": "2021-06-15",
        "balance": 80.50
    },
    {
        "id": 3,
        "name": "Carol Williams",
        "email": "carol@example.com",
        "phone": "3456789012",
        "address": "789 Banana Blvd",
        "membership": "Bronze",
        "join_date": "2020-01-10",
        "balance": 20.00
    },
    {
        "id": 4,
        "name": "David Brown",
        "email": "david@example.com",
        "phone": "4567890123",
        "address": "321 Pear Dr",
        "membership": "Gold",
        "join_date": "2023-03-12",
        "balance": 200.00
    },
    {
        "id": 5,
        "name": "Eve Davis",
        "email": "eve@example.com",
        "phone": "5678901234",
        "address": "654 Grape Ln",
        "membership": "Silver",
        "join_date": "2022-11-19",
        "balance": 95.25
    },
    {
        "id": 6,
        "name": "Frank Miller",
        "email": "frank@example.com",
        "phone": "6789012345",
        "address": "987 Peach Way",
        "membership": "Bronze",
        "join_date": "2021-08-05",
        "balance": 45.00
    },
    {
        "id": 7,
        "name": "Grace Lee",
        "email": "grace@example.com",
        "phone": "7890123456",
        "address": "159 Plum St",
        "membership": "Gold",
        "join_date": "2023-01-01",
        "balance": 300.00
    },
    {
        "id": 8,
        "name": "Henry Wilson",
        "email": "henry@example.com",
        "phone": "8901234567",
        "address": "753 Kiwi Rd",
        "membership": "Silver",
        "join_date": "2020-10-30",
        "balance": 65.10
    },
    {
        "id": 9,
        "name": "Isla Moore",
        "email": "isla@example.com",
        "phone": "9012345678",
        "address": "357 Mango Pkwy",
        "membership": "Bronze",
        "join_date": "2022-02-20",
        "balance": 30.00
    },
    {
        "id": 10,
        "name": "Jack Taylor",
        "email": "jack@example.com",
        "phone": "0123456789",
        "address": "951 Cherry Cir",
        "membership": "Gold",
        "join_date": "2021-09-09",
        "balance": 170.45
    }
]